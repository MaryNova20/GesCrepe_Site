package com.biat.gescrepe.services;

import com.biat.gescrepe.servicegeneric.BaseServiceBeanLocal;
import com.biat.gescrepe.entities.Demande;
import javax.ejb.Local;

/**
 *
 * @author MENSAH Y.O.D.
 */
@Local
public interface DemandeServiceBeanLocal extends BaseServiceBeanLocal<Demande, Integer>{
    
}