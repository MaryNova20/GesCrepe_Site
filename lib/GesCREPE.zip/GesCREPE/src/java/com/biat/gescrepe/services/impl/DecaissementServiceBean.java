package com.biat.gescrepe.services.impl;

import com.biat.gescrepe.services.DecaissementServiceBeanLocal;
import com.biat.gescrepe.servicegeneric.impl.BaseServiceBean;
import com.biat.gescrepe.entities.Decaissement;
import javax.ejb.Stateless;

/**
 *
 * @author MENSAH Y.O.D
 */
@Stateless
public class DecaissementServiceBean extends BaseServiceBean<Decaissement,Integer> implements DecaissementServiceBeanLocal {

    public DecaissementServiceBean() {
        super(Decaissement.class);
    }

    
}
