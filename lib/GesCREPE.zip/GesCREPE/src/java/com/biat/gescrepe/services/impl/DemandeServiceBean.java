package com.biat.gescrepe.services.impl;

import com.biat.gescrepe.services.DemandeServiceBeanLocal;
import com.biat.gescrepe.servicegeneric.impl.BaseServiceBean;
import com.biat.gescrepe.entities.Demande;
import javax.ejb.Stateless;

/**
 *
 * @author MENSAH Y.O.D
 */
@Stateless
public class DemandeServiceBean extends BaseServiceBean<Demande,Integer> implements DemandeServiceBeanLocal {

    public DemandeServiceBean() {
        super(Demande.class);
    }

    
}
