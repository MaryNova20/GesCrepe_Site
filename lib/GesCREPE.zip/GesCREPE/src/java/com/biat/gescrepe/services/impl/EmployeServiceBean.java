package com.biat.gescrepe.services.impl;

import com.biat.gescrepe.services.EmployeServiceBeanLocal;
import com.biat.gescrepe.servicegeneric.impl.BaseServiceBean;
import com.biat.gescrepe.entities.Employe;
import javax.ejb.Stateless;

/**
 *
 * @author MENSAH Y.O.D
 */
@Stateless
public class EmployeServiceBean extends BaseServiceBean<Employe,Integer> implements EmployeServiceBeanLocal {

    public EmployeServiceBean() {
        super(Employe.class);
    }

    
}
