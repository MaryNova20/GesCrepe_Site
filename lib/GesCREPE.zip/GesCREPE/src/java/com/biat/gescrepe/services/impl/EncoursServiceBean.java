package com.biat.gescrepe.services.impl;

import com.biat.gescrepe.services.EncoursServiceBeanLocal;
import com.biat.gescrepe.servicegeneric.impl.BaseServiceBean;
import com.biat.gescrepe.entities.Encours;
import javax.ejb.Stateless;

/**
 *
 * @author MENSAH Y.O.D
 */
@Stateless
public class EncoursServiceBean extends BaseServiceBean<Encours,Integer> implements EncoursServiceBeanLocal {

    public EncoursServiceBean() {
        super(Encours.class);
    }

    
}
